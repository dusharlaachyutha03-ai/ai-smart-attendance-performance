"""
Creates DEMO csv files (made-up students) so you can test the upload page and the ML model.
This is NOT real student data. Run:  python sample_data/make_demo_files.py
Upload the three files on the Upload page in this order: students, attendance, performance.
"""
import os
import random
from datetime import date, timedelta

import pandas as pd

random.seed(7)
folder = os.path.dirname(os.path.abspath(__file__))
first = ["Asha", "Ravi", "Meena", "Kiran", "Sana", "Arjun", "Divya", "Imran", "Neha", "Vikram",
         "Priya", "Rahul", "Anita", "Suresh", "Pooja", "Farhan", "Lakshmi", "Tarun", "Isha", "Manoj"]
depts = ["CSE", "IT", "ECE", "Mechanical"]

students, attendance, performance = [], [], []
days = [date(2026, 1, 5) + timedelta(days=i) for i in range(30) if (date(2026, 1, 5) + timedelta(days=i)).weekday() < 5]

for i, name in enumerate(first, start=1):
    sid = f"S{i:03d}"
    students.append([sid, f"R{i:03d}", name, depts[i % 4], 1 + i % 4, f"{name.lower()}@college.edu"])
    att_rate = random.choice([0.95, 0.9, 0.85, 0.8, 0.7, 0.6])
    skill = random.randint(35, 90) + (10 if att_rate > 0.85 else -5)
    for d in days:
        attendance.append([sid, d.isoformat(), "Present" if random.random() < att_rate else "Absent"])
    for subject in ["Mathematics", "Physics", "Programming", "English"]:
        mark = max(0, min(100, skill + random.randint(-12, 12)))
        performance.append([sid, subject, mark, "Mid Term"])

pd.DataFrame(students, columns=["student_id", "roll_number", "name", "department", "year", "email"]).to_csv(
    os.path.join(folder, "demo_students.csv"), index=False)
pd.DataFrame(attendance, columns=["student_id", "date", "status"]).to_csv(
    os.path.join(folder, "demo_attendance.csv"), index=False)
pd.DataFrame(performance, columns=["student_id", "subject", "marks", "exam_type"]).to_csv(
    os.path.join(folder, "demo_performance.csv"), index=False)
print("Demo files created in", folder)
