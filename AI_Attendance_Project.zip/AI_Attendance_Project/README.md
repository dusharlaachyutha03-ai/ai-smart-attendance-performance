# AI-Powered Smart Attendance and Student Performance Analytics

Streamlit + SQLite + scikit-learn (RandomForest) college project.
Default login: **admin / admin123**

## Step-by-step setup (Windows, Command Prompt)

**STEP 1 - Install Python 3.11** (https://www.python.org/downloads/). Tick "Add Python to PATH".
Check:  `python --version`   -> expected: `Python 3.11.x`

**STEP 2 - Open the project folder** (the folder that contains app.py)
`cd C:\path\to\AI_Attendance_Project`   -> then `dir` should list app.py, database.py ...

**STEP 3 - Create a virtual environment** (keeps this project's packages separate)
`python -m venv venv`   -> a `venv` folder appears.

**STEP 4 - Activate it**
`venv\Scripts\activate`   -> your prompt starts with `(venv)`.

**STEP 5 - Install the packages**
`pip install -r requirements.txt`   -> ends with "Successfully installed ...".

**STEP 6 - Run the app**
`streamlit run app.py`   -> browser opens at http://localhost:8501 (the database file data/attendance.db is created automatically).

**STEP 7 - Log in** with admin / admin123.

**STEP 8 - (Optional) Try it with DEMO data**
In a second CMD window (venv active):  `python sample_data/make_demo_files.py`
In the app open **Upload CSV / Excel** and upload, in this order:
demo_students.csv -> demo_attendance.csv -> demo_performance.csv (click Import each time).
Then open **AI Prediction & Risk** -> **Train Model** -> **Predict Student**.
(These are made-up students for testing only. Use your own real data for your submission.)

## How the AI works
- Features: attendance %, average marks, number of subjects, number of absent days (read from SQLite).
- Training label: because there is no "final result" column, a student is **At Risk (1)** if attendance < 75% OR average marks < 50, else **Good (0)**. This is computed from real records - nothing is invented.
- Needs at least 10 students having both attendance and marks, with at least 2 in each class. Otherwise the app shows: "Not enough data to train the model. Add more student attendance and performance records."
- The model is saved to models/performance_model.pkl with joblib and loaded for predictions. Retrain after adding lots of new data.
- Because labels come from the thresholds, the high test accuracy is expected; say this honestly in your viva. The model's value is the risk probability and the combined pattern.

## Troubleshooting
- `'streamlit' is not recognized` -> activate the venv (STEP 4) and repeat STEP 5.
- Port busy -> `streamlit run app.py --server.port 8502`
- Start with a clean database -> close the app, delete data/attendance.db, run again.
