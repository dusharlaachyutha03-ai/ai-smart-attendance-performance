"""
ml_model.py  -  Real machine learning with scikit-learn (RandomForestClassifier).

HOW THE TRAINING LABEL IS CREATED (important, be honest in your viva):
Your database has no "final result" column, so the label is created from the
REAL attendance and marks of each student using college rules:
    At Risk (1)  if attendance < 75%  OR  average marks < 50
    Good    (0)  otherwise
The Random Forest then learns from the 4 features (attendance %, average marks,
number of subjects, absent days) and gives a risk PROBABILITY for each student.
No fake or random data is ever generated.
"""
import os
from datetime import datetime

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split

import database as db

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE_DIR, "models")
MODEL_PATH = os.path.join(MODEL_DIR, "performance_model.pkl")

FEATURES = ["attendance_pct", "avg_marks", "num_subjects", "absent_days"]
ATTENDANCE_LIMIT = 75
MARKS_LIMIT = 50
MIN_STUDENTS = 10
MIN_PER_CLASS = 2

NOT_ENOUGH = "Not enough data to train the model. Add more student attendance and performance records."


# ----------------------------------------------------------------------
# Training data
# ----------------------------------------------------------------------
def rule_label(attendance, marks):
    """1 = At Risk, 0 = Good."""
    return int(attendance < ATTENDANCE_LIMIT or marks < MARKS_LIMIT)


def get_training_data():
    """Only students that have BOTH attendance and marks records."""
    summary = db.get_student_summary()
    if summary.empty:
        return summary
    df = summary.dropna(subset=["attendance_pct", "avg_marks"]).copy()
    df = df[(df["total_classes"] > 0) & (df["num_subjects"] > 0)]
    if df.empty:
        return df
    df["label"] = [rule_label(a, m) for a, m in zip(df["attendance_pct"], df["avg_marks"])]
    return df


def train_model():
    """Train + save the model. Returns (success, message, info_dict)."""
    df = get_training_data()
    if len(df) < MIN_STUDENTS:
        return False, (f"{NOT_ENOUGH} (Found {len(df)} students with both attendance and marks; "
                       f"at least {MIN_STUDENTS} are needed.)"), {}
    counts = df["label"].value_counts()
    if len(counts) < 2 or counts.min() < MIN_PER_CLASS:
        return False, (f"{NOT_ENOUGH} The model needs at least {MIN_PER_CLASS} Good and "
                       f"{MIN_PER_CLASS} At-Risk students to learn from."), {}

    X = df[FEATURES].astype(float)
    y = df["label"].astype(int)
    model = RandomForestClassifier(n_estimators=200, random_state=42, class_weight="balanced")
    accuracy = None
    try:
        if len(df) >= 20 and counts.min() >= 4:
            X_tr, X_te, y_tr, y_te = train_test_split(
                X, y, test_size=0.25, stratify=y, random_state=42)
            model.fit(X_tr, y_tr)
            accuracy = float(accuracy_score(y_te, model.predict(X_te)))
        model.fit(X, y)  # final model uses all students

        os.makedirs(MODEL_DIR, exist_ok=True)
        bundle = {
            "model": model,
            "features": FEATURES,
            "trained_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "n_students": int(len(df)),
            "n_at_risk": int((y == 1).sum()),
            "n_good": int((y == 0).sum()),
            "accuracy": accuracy,
        }
        joblib.dump(bundle, MODEL_PATH)
    except Exception as e:  # noqa
        print("training error:", e)
        return False, "Model training failed. Please check your data and try again.", {}
    return True, "Model trained and saved successfully.", bundle


def load_model():
    """Load the saved model bundle, or None if it does not exist / cannot be read."""
    if not os.path.exists(MODEL_PATH):
        return None
    try:
        return joblib.load(MODEL_PATH)
    except Exception as e:  # noqa
        print("load error:", e)
        return None


def feature_importance(bundle):
    imp = bundle["model"].feature_importances_
    return pd.DataFrame({"feature": bundle["features"], "importance": imp}).sort_values(
        "importance", ascending=False)


# ----------------------------------------------------------------------
# Prediction
# ----------------------------------------------------------------------
def build_reason(att, marks, absent):
    reasons = []
    if att < ATTENDANCE_LIMIT:
        reasons.append(f"Attendance is {att:.1f}% (below {ATTENDANCE_LIMIT}%)")
    if marks < MARKS_LIMIT:
        reasons.append(f"Average marks are {marks:.1f} (below {MARKS_LIMIT})")
    if absent >= 5 and att >= ATTENDANCE_LIMIT:
        reasons.append(f"{int(absent)} absent days recorded")
    return "; ".join(reasons)


def build_recommendation(att, marks, risk):
    tips = []
    if att < ATTENDANCE_LIMIT:
        tips.append("Improve attendance - attend more classes")
    if marks < MARKS_LIMIT:
        tips.append("Focus on low-scoring subjects")
    if not tips:
        tips.append("Maintain current performance")
        if risk == "At Risk":  # model says risky although rules are fine
            tips.append("Keep attendance and marks steady - the model sees a borderline pattern")
    return "; ".join(tips)


def weak_subjects(student_id):
    """Subjects where the student's average is below the marks limit."""
    marks = db.get_marks(student_id)
    if marks.empty:
        return []
    avg = marks.groupby("subject")["marks"].mean()
    return [f"{s} ({v:.0f})" for s, v in avg.items() if v < MARKS_LIMIT]


def get_risk_table():
    """
    Returns one row per student with: risk, risk_probability (%), reason, recommendation.
    Uses the saved ML model when it exists, otherwise falls back to threshold rules.
    """
    df = db.get_student_summary()
    if df.empty:
        return df
    bundle = load_model()

    df["risk"] = "No Data"
    df["risk_probability"] = np.nan
    df["method"] = "-"
    df["reason"] = "Attendance or marks not recorded yet"
    df["recommendation"] = "Add attendance and marks records"

    has = df["attendance_pct"].notna() & df["avg_marks"].notna() & (df["num_subjects"] > 0)
    if has.any():
        sub = df.loc[has]
        if bundle is not None:
            model = bundle["model"]
            proba = model.predict_proba(sub[bundle["features"]].astype(float))
            col = list(model.classes_).index(1)
            p = proba[:, col]
            df.loc[has, "risk_probability"] = np.round(p * 100, 1)
            df.loc[has, "risk"] = np.where(p >= 0.5, "At Risk", "Good")
            df.loc[has, "method"] = "ML model"
        else:
            labels = [rule_label(a, m) for a, m in zip(sub["attendance_pct"], sub["avg_marks"])]
            df.loc[has, "risk"] = ["At Risk" if v else "Good" for v in labels]
            df.loc[has, "method"] = "Threshold rules"

        for idx in sub.index:
            r = df.loc[idx]
            reason = build_reason(r["attendance_pct"], r["avg_marks"], r["absent_days"])
            if r["risk"] == "At Risk" and not reason:
                reason = "Model found a risky pattern across attendance and marks"
            if r["risk"] == "Good":
                reason = "Attendance and marks are above the required limits"
            df.at[idx, "reason"] = reason
            df.at[idx, "recommendation"] = build_recommendation(
                r["attendance_pct"], r["avg_marks"], r["risk"])
    return df
