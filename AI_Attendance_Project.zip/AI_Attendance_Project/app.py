"""
app.py  -  Main file. Run with:  streamlit run app.py
Handles: page setup, login, sidebar navigation.
"""
import hmac

import streamlit as st

import database as db

st.set_page_config(page_title="AI Smart Attendance", page_icon="🎓", layout="wide")

st.markdown(
    """
    <style>
    [data-testid="stMetric"] {background:#F5F8FC; border:1px solid #DCE6F2;
        padding:14px 16px; border-radius:10px;}
    h1 {color:#1F3A5F;}
    </style>
    """,
    unsafe_allow_html=True,
)

db.init_db()

# Simple demo login (fine for a college project).
USERS = {"admin": "admin123"}

if "logged_in" not in st.session_state:
    st.session_state.logged_in = False
    st.session_state.username = ""


def login_page():
    _, middle, _ = st.columns([1, 1.2, 1])
    with middle:
        st.title("🎓 AI Smart Attendance")
        st.caption("Student Performance Analytics - Teacher / Admin Login")
        with st.form("login_form"):
            username = st.text_input("Username")
            password = st.text_input("Password", type="password")
            submitted = st.form_submit_button("Login", use_container_width=True)
        if submitted:
            expected = USERS.get(username.strip())
            if expected is not None and hmac.compare_digest(expected, password):
                st.session_state.logged_in = True
                st.session_state.username = username.strip()
                st.rerun()
            else:
                st.error("Invalid username or password.")
        st.info("Default login: admin / admin123")


if not st.session_state.logged_in:
    login_page()
    st.stop()

pages = [
    st.Page("pages/dashboard.py", title="Dashboard", icon="📊", default=True),
    st.Page("pages/students.py", title="Students", icon="🎓"),
    st.Page("pages/attendance.py", title="Attendance", icon="📅"),
    st.Page("pages/performance.py", title="Performance", icon="📝"),
    st.Page("pages/prediction.py", title="AI Prediction & Risk", icon="🤖"),
    st.Page("pages/analytics.py", title="Analytics", icon="📈"),
    st.Page("pages/upload.py", title="Upload CSV / Excel", icon="📤"),
    st.Page("pages/reports.py", title="Reports", icon="📥"),
]
navigation = st.navigation(pages)

with st.sidebar:
    st.markdown("---")
    st.write(f"👤 Logged in as **{st.session_state.username}**")
    if st.button("Logout", use_container_width=True):
        st.session_state.logged_in = False
        st.session_state.username = ""
        st.rerun()

navigation.run()
