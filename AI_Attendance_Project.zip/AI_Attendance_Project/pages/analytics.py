import streamlit as st

import analytics as an
import database as db
import ml_model as ml

st.title("📈 Analytics")

summary = db.get_student_summary()
if summary.empty:
    st.info("No students found. Add students, attendance and marks first.")
    st.stop()

marks = db.get_marks()


def show(fig, message="Not enough data for this chart yet."):
    if fig is None:
        st.info(message)
    else:
        st.plotly_chart(fig, use_container_width=True)


tab1, tab2, tab3, tab4 = st.tabs(["Attendance", "Marks", "Correlation", "Top / Low Students"])

with tab1:
    show(an.student_attendance_fig(summary))
    st.subheader("Low-attendance students (below 75%)")
    low = an.low_attendance_students(summary)
    if low.empty:
        st.success("No low-attendance students.")
    else:
        st.dataframe(low, use_container_width=True, hide_index=True)

with tab2:
    show(an.subject_marks_fig(marks))
    show(an.department_performance_fig(summary))

with tab3:
    show(an.attendance_vs_marks_fig(summary))
    r = an.correlation(summary)
    if r is None:
        st.info("Need at least 3 students with different attendance and marks values to calculate correlation.")
    else:
        st.metric("Correlation (attendance vs marks)", f"{r:.2f}")
        if r >= 0.5:
            st.success("Strong positive relationship: students who attend more tend to score higher.")
        elif r >= 0.2:
            st.info("Weak positive relationship between attendance and marks.")
        elif r > -0.2:
            st.info("Almost no linear relationship between attendance and marks.")
        else:
            st.warning("Negative relationship found in the data.")

with tab4:
    c1, c2 = st.columns(2)
    with c1:
        st.subheader("🏆 Top-performing students")
        top = an.top_students(summary)
        st.dataframe(top, use_container_width=True, hide_index=True) if not top.empty else st.info("No marks yet.")
    with c2:
        st.subheader("⬇️ Low-performing students")
        bottom = an.low_students(summary)
        st.dataframe(bottom, use_container_width=True, hide_index=True) if not bottom.empty else st.info("No marks yet.")
