import streamlit as st

import database as db

st.title("🧑‍🎓 Student Management")

if "flash" in st.session_state:  # message saved before a st.rerun()
    st.success(st.session_state.pop("flash"))

YEARS = [1, 2, 3, 4]
tab_add, tab_view, tab_search, tab_update, tab_delete = st.tabs(
    ["➕ Add", "📋 View All", "🔍 Search", "✏️ Update", "🗑️ Delete"])

# ---------------- Add ----------------
with tab_add:
    with st.form("add_student_form", clear_on_submit=True):
        c1, c2 = st.columns(2)
        sid = c1.text_input("Student ID (example: S001)")
        roll = c2.text_input("Roll Number")
        name = c1.text_input("Student Name")
        email = c2.text_input("Email")
        dept = c1.selectbox("Department", db.DEPARTMENTS)
        year = c2.selectbox("Year", YEARS)
        submitted = st.form_submit_button("Add Student")
    if submitted:
        ok, msg = db.add_student(sid, roll, name, dept, year, email)
        (st.success if ok else st.error)(msg)

students = db.get_students()  # read after the add so the tables below are fresh

# ---------------- View ----------------
with tab_view:
    if students.empty:
        st.info("No students found. Add a student first.")
    else:
        st.write(f"Total students: **{len(students)}**")
        st.dataframe(students, use_container_width=True, hide_index=True)

# ---------------- Search ----------------
with tab_search:
    term = st.text_input("Search by ID, roll number, name, department or email")
    if term.strip():
        found = db.search_students(term)
        if found.empty:
            st.warning("No matching students found.")
        else:
            st.dataframe(found, use_container_width=True, hide_index=True)
    else:
        st.caption("Type something to search.")

# ---------------- Update ----------------
with tab_update:
    if students.empty:
        st.info("No students to update.")
    else:
        names = {r["student_id"]: f"{r['student_id']} - {r['name']}" for _, r in students.iterrows()}
        chosen = st.selectbox("Select student", list(names), format_func=lambda x: names[x], key="upd_pick")
        cur = students[students["student_id"] == chosen].iloc[0]
        dept_options = db.DEPARTMENTS if cur["department"] in db.DEPARTMENTS else db.DEPARTMENTS + [cur["department"]]
        year_options = YEARS if int(cur["year"]) in YEARS else YEARS + [int(cur["year"])]
        with st.form(f"update_form_{chosen}"):
            st.text_input("Student ID (cannot be changed)", value=chosen, disabled=True)
            u_roll = st.text_input("Roll Number", value=cur["roll_number"])
            u_name = st.text_input("Student Name", value=cur["name"])
            u_dept = st.selectbox("Department", dept_options, index=dept_options.index(cur["department"]))
            u_year = st.selectbox("Year", year_options, index=year_options.index(int(cur["year"])))
            u_email = st.text_input("Email", value=cur["email"])
            upd = st.form_submit_button("Update Student")
        if upd:
            ok, msg = db.update_student(chosen, u_roll, u_name, u_dept, u_year, u_email)
            if ok:
                st.session_state["flash"] = msg
                st.rerun()
            else:
                st.error(msg)

# ---------------- Delete ----------------
with tab_delete:
    if students.empty:
        st.info("No students to delete.")
    else:
        names = {r["student_id"]: f"{r['student_id']} - {r['name']}" for _, r in students.iterrows()}
        del_id = st.selectbox("Select student to delete", list(names), format_func=lambda x: names[x], key="del_pick")
        st.warning("Deleting a student also deletes all of their attendance and marks.")
        with st.form("delete_form", clear_on_submit=True):
            sure = st.checkbox("Yes, I want to delete this student")
            go = st.form_submit_button("Delete Student", type="primary")
        if go:
            if not sure:
                st.warning("Please tick the confirmation box first.")
            else:
                ok, msg = db.delete_student(del_id)
                if ok:
                    st.session_state["flash"] = msg
                    st.rerun()
                else:
                    st.error(msg)
