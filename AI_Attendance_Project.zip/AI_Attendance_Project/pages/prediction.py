import plotly.express as px
import streamlit as st

import analytics as an
import database as db
import ml_model as ml

st.title("🤖 AI Prediction & Student Risk Analysis")

tab_train, tab_predict, tab_risk = st.tabs(["🧠 Train Model", "🎯 Predict Student", "⚠️ Risk Analysis"])

# ---------------- Train ----------------
with tab_train:
    train_df = ml.get_training_data()
    st.write(f"Students with both attendance and marks records: **{len(train_df)}** "
             f"(minimum needed: {ml.MIN_STUDENTS})")
    st.caption(
        "Features used: attendance %, average marks, number of subjects, number of absent days. "
        f"Training label (from real data): At Risk = attendance below {ml.ATTENDANCE_LIMIT}% "
        f"OR average marks below {ml.MARKS_LIMIT}; otherwise Good.")
    if st.button("Train Model", type="primary"):
        with st.spinner("Training the Random Forest model..."):
            ok, msg, info = ml.train_model()
        if ok:
            st.success(msg)
        else:
            st.error(msg)

    bundle = ml.load_model()
    if bundle is None:
        st.warning("No trained model found yet.")
    else:
        st.subheader("Current saved model")
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Trained at", bundle["trained_at"])
        c2.metric("Students used", bundle["n_students"])
        c3.metric("Good / At Risk", f"{bundle['n_good']} / {bundle['n_at_risk']}")
        acc = bundle.get("accuracy")
        c4.metric("Test accuracy", f"{acc * 100:.0f}%" if acc is not None else "Not tested (few records)")
        imp = ml.feature_importance(bundle)
        fig = px.bar(imp, x="importance", y="feature", orientation="h", template="plotly_white",
                     title="Feature importance")
        st.plotly_chart(fig, use_container_width=True)
        st.caption("Retrain the model after adding or changing many records.")

# ---------------- Predict ----------------
with tab_predict:
    bundle = ml.load_model()
    students = db.get_students()
    if students.empty:
        st.info("No students found.")
    elif bundle is None:
        st.warning("The model is not trained yet. Go to the 'Train Model' tab first.")
    else:
        names = {r["student_id"]: f"{r['student_id']} - {r['name']}" for _, r in students.iterrows()}
        sid = st.selectbox("Select student", list(names), format_func=lambda x: names[x], key="pred_pick")
        if st.button("Predict Risk"):
            st.session_state["predicted_id"] = sid
        if st.session_state.get("predicted_id") == sid:
            table = ml.get_risk_table()
            row = table[table["student_id"] == sid].iloc[0]
            if row["risk"] == "No Data":
                st.warning("This student has no attendance or marks yet, so a prediction is not possible.")
            else:
                if row["risk"] == "At Risk":
                    st.error(f"Prediction: AT RISK")
                else:
                    st.success("Prediction: GOOD PERFORMANCE")
                m1, m2, m3 = st.columns(3)
                m1.metric("Risk probability", f"{row['risk_probability']:.1f}%")
                m2.metric("Attendance", f"{row['attendance_pct']:.1f}%")
                m3.metric("Average marks", f"{row['avg_marks']:.1f}")
                st.write(f"**Reason:** {row['reason']}")
                st.write(f"**Recommendation:** {row['recommendation']}")
                weak = ml.weak_subjects(sid)
                if weak:
                    st.write("**Low-scoring subjects:** " + ", ".join(weak))

# ---------------- Risk analysis ----------------
with tab_risk:
    risk = ml.get_risk_table()
    if risk.empty:
        st.info("No students found.")
    else:
        if ml.load_model() is None:
            st.warning("Model not trained - classification below uses simple threshold rules only.")
        shown = risk[["student_id", "name", "attendance_pct", "avg_marks", "risk",
                      "risk_probability", "method", "recommendation"]].rename(columns={
            "student_id": "Student ID", "name": "Student", "attendance_pct": "Attendance %",
            "avg_marks": "Average Marks", "risk": "Risk", "risk_probability": "Probability %",
            "method": "Method", "recommendation": "Recommendation"})
        choice = st.radio("Show", ["All", "At Risk", "Good", "No Data"], horizontal=True)
        if choice != "All":
            shown = shown[shown["Risk"] == choice]
        st.dataframe(shown, use_container_width=True, hide_index=True)
        fig = an.risk_fig(risk)
        if fig is not None:
            st.plotly_chart(fig, use_container_width=True)
