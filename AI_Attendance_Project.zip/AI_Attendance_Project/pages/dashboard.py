from datetime import date

import streamlit as st

import analytics as an
import database as db
import ml_model as ml

st.title("📊 Dashboard")

summary = db.get_student_summary()
if summary.empty:
    st.info("No students yet. Open the **Students** page to add students, "
            "or the **Upload** page to import a CSV/Excel file.")
    st.stop()

risk_df = ml.get_risk_table()
history = db.get_attendance_history()
present_today, absent_today = db.get_today_counts(date.today().isoformat())

avg_att = summary["attendance_pct"].mean()
avg_marks = summary["avg_marks"].mean()
at_risk = int((risk_df["risk"] == "At Risk").sum())

c1, c2, c3 = st.columns(3)
c1.metric("Total Students", len(summary))
c2.metric("Average Attendance", f"{avg_att:.1f}%" if avg_att == avg_att else "N/A")
c3.metric("Average Marks", f"{avg_marks:.1f}" if avg_marks == avg_marks else "N/A")
c4, c5, c6 = st.columns(3)
c4.metric("At-Risk Students", at_risk)
c5.metric("Present Today", present_today)
c6.metric("Absent Today", absent_today)

if ml.load_model() is None:
    st.warning("AI model is not trained yet - risk is shown using simple threshold rules. "
               "Train it on the **AI Prediction & Risk** page.")

st.markdown("---")
left, right = st.columns(2)
charts = [
    (left, an.attendance_overview_fig(history), "No attendance records yet."),
    (right, an.student_performance_fig(summary), "No marks records yet."),
    (left, an.attendance_vs_marks_fig(summary), "Need both attendance and marks for this chart."),
    (right, an.department_students_fig(summary), "No data."),
    (left, an.risk_fig(risk_df), "No data."),
]
for col, fig, empty_msg in charts:
    with col:
        if fig is None:
            st.info(empty_msg)
        else:
            st.plotly_chart(fig, use_container_width=True)
