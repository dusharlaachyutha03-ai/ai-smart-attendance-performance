import streamlit as st

import database as db

st.title("📝 Performance Management")

if "flash" in st.session_state:
    st.success(st.session_state.pop("flash"))

students = db.get_students()
if students.empty:
    st.info("No students found. Add students first.")
    st.stop()

names = {r["student_id"]: f"{r['student_id']} - {r['name']}" for _, r in students.iterrows()}

tab_add, tab_manage, tab_avg = st.tabs(["➕ Add Marks", "📋 View / Update / Delete", "📊 Average Marks"])

# ---------------- Add ----------------
with tab_add:
    with st.form("marks_form", clear_on_submit=True):
        sid = st.selectbox("Student", list(names), format_func=lambda x: names[x])
        subject = st.text_input("Subject (example: Mathematics)")
        marks = st.number_input("Marks (0 - 100)", min_value=0.0, max_value=100.0, value=0.0, step=1.0)
        exam = st.selectbox("Exam type", db.EXAM_TYPES)
        save = st.form_submit_button("Add Marks")
    if save:
        ok, msg = db.add_marks(sid, subject, marks, exam)
        (st.success if ok else st.error)(msg)

# ---------------- View / Update / Delete ----------------
with tab_manage:
    options = [None] + list(names)
    pick = st.selectbox("Filter by student", options, format_func=lambda x: "All students" if x is None else names[x],
                        key="marks_filter")
    data = db.get_marks(student_id=pick)
    if data.empty:
        st.info("No marks records found.")
    else:
        st.dataframe(data, use_container_width=True, hide_index=True)
        st.write(f"Average marks of the records shown: **{data['marks'].mean():.2f}**")

        st.subheader("Update or delete a record")
        labels = {int(r["id"]): f"#{int(r['id'])} | {r['student_id']} | {r['subject']} | {r['exam_type']} | {r['marks']:.0f}"
                  for _, r in data.iterrows()}
        rec = st.selectbox("Select record", list(labels), format_func=lambda x: labels[x], key="marks_rec")
        cur = data[data["id"] == rec].iloc[0]
        exam_options = db.EXAM_TYPES if cur["exam_type"] in db.EXAM_TYPES else db.EXAM_TYPES + [cur["exam_type"]]
        with st.form(f"marks_update_{rec}"):
            u_subject = st.text_input("Subject", value=cur["subject"])
            u_marks = st.number_input("Marks", min_value=0.0, max_value=100.0, value=float(cur["marks"]), step=1.0)
            u_exam = st.selectbox("Exam type", exam_options, index=exam_options.index(cur["exam_type"]))
            upd = st.form_submit_button("Update Marks")
        if upd:
            ok, msg = db.update_marks(rec, u_subject, u_marks, u_exam)
            if ok:
                st.session_state["flash"] = msg
                st.rerun()
            else:
                st.error(msg)
        with st.form(f"marks_delete_{rec}", clear_on_submit=True):
            sure = st.checkbox("Yes, delete the selected record")
            dele = st.form_submit_button("Delete Marks", type="primary")
        if dele:
            if not sure:
                st.warning("Please tick the confirmation box first.")
            else:
                ok, msg = db.delete_marks(rec)
                if ok:
                    st.session_state["flash"] = msg
                    st.rerun()
                else:
                    st.error(msg)

# ---------------- Averages ----------------
with tab_avg:
    summary = db.get_student_summary()
    avg = summary[summary["num_subjects"] > 0][["student_id", "name", "department", "num_subjects", "avg_marks"]]
    if avg.empty:
        st.info("No marks recorded yet.")
    else:
        st.subheader("Average marks per student")
        st.dataframe(avg.sort_values("avg_marks", ascending=False), use_container_width=True, hide_index=True)
        marks_all = db.get_marks()
        st.subheader("Average marks per subject")
        subj = marks_all.groupby("subject", as_index=False)["marks"].mean().round(2)
        subj.columns = ["subject", "average_marks"]
        st.dataframe(subj, use_container_width=True, hide_index=True)
