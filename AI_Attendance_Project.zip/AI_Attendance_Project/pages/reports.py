from io import BytesIO

import pandas as pd
import streamlit as st

import database as db
import ml_model as ml

st.title("📥 Reports")


def to_csv(df):
    return df.to_csv(index=False).encode("utf-8")


def to_excel(df):
    buffer = BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Report")
    return buffer.getvalue()


def report_block(title, df, file_name, key):
    st.subheader(title)
    if df is None or df.empty:
        st.info("No data available for this report yet.")
        return
    st.dataframe(df, use_container_width=True, hide_index=True)
    c1, c2, _ = st.columns([1, 1, 3])
    c1.download_button("Download CSV", to_csv(df), file_name=f"{file_name}.csv",
                       mime="text/csv", key=f"csv_{key}")
    c2.download_button("Download Excel", to_excel(df), file_name=f"{file_name}.xlsx",
                       mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                       key=f"xlsx_{key}")


risk = ml.get_risk_table()
if not risk.empty:
    risk = risk[["student_id", "name", "department", "attendance_pct", "avg_marks", "num_subjects",
                 "absent_days", "risk", "risk_probability", "method", "reason", "recommendation"]]

tab1, tab2, tab3, tab4 = st.tabs(["Student Report", "Attendance Report", "Performance Report", "AI Risk Report"])
with tab1:
    report_block("Student report", db.get_students(), "student_report", "students")
with tab2:
    report_block("Attendance report", db.get_attendance_history(), "attendance_report", "attendance")
with tab3:
    report_block("Performance report", db.get_marks(), "performance_report", "performance")
with tab4:
    report_block("AI risk report", risk, "ai_risk_report", "risk")
