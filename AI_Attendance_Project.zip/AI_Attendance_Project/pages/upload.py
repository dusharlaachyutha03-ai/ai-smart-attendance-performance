import pandas as pd
import streamlit as st

import database as db

st.title("📤 Upload CSV / Excel")
st.caption("Upload in this order: 1) Students  2) Attendance  3) Performance "
           "(attendance and marks need the student to exist already).")


def read_file(uploaded):
    """Read CSV/Excel as text and normalise column names (lowercase, underscores)."""
    name = uploaded.name.lower()
    if name.endswith(".csv"):
        df = pd.read_csv(uploaded, dtype=str, encoding="utf-8-sig")
    else:
        df = pd.read_excel(uploaded, dtype=str, engine="openpyxl")
    df.columns = [str(c).strip().lower().replace(" ", "_") for c in df.columns]
    return df


def upload_section(title, required, import_func, key, example_row):
    st.write(f"Required columns: `{', '.join(required)}`")
    template = pd.DataFrame([example_row], columns=required).to_csv(index=False).encode("utf-8")
    st.download_button(f"Download {title} CSV template", template, file_name=f"{key}_template.csv",
                       mime="text/csv", key=f"tpl_{key}")
    uploaded = st.file_uploader(f"Choose {title} file (.csv or .xlsx)", type=["csv", "xlsx"], key=f"up_{key}")
    if uploaded is None:
        return
    try:
        df = read_file(uploaded)
    except Exception:  # noqa
        st.error("Could not read this file. Please upload a valid CSV or Excel (.xlsx) file.")
        return
    missing = [c for c in required if c not in df.columns]
    if missing:
        st.error(f"Missing required column(s): {', '.join(missing)}. "
                 f"Columns found in your file: {', '.join(df.columns) or 'none'}.")
        return
    if df.empty:
        st.warning("The file has no data rows.")
        return
    st.success(f"File looks valid: {len(df)} rows found. Preview:")
    st.dataframe(df.head(10), use_container_width=True, hide_index=True)
    if st.button(f"Import {title} into database", key=f"btn_{key}", type="primary"):
        inserted, skipped, errors = import_func(df[required])
        if inserted:
            st.success(f"{inserted} record(s) imported.")
        if skipped:
            st.warning(f"{skipped} duplicate record(s) were skipped.")
        if errors:
            st.error(f"{len(errors)} row(s) were rejected:")
            st.code("\n".join(errors[:30]) + ("\n..." if len(errors) > 30 else ""))
        if not inserted and not skipped and not errors:
            st.info("Nothing was imported.")


tab_s, tab_a, tab_p = st.tabs(["Students", "Attendance", "Performance"])
with tab_s:
    upload_section("Student", ["student_id", "roll_number", "name", "department", "year", "email"],
                   db.import_students, "students",
                   ["S001", "R001", "Asha Rao", "CSE", 2, "asha@example.com"])
with tab_a:
    upload_section("Attendance", ["student_id", "date", "status"],
                   db.import_attendance, "attendance", ["S001", "2026-01-05", "Present"])
with tab_p:
    upload_section("Performance", ["student_id", "subject", "marks", "exam_type"],
                   db.import_performance, "performance", ["S001", "Mathematics", 78, "Mid Term"])
