from datetime import date

import streamlit as st

import analytics as an
import database as db

st.title("🗓️ Attendance Management")

if "flash" in st.session_state:
    st.success(st.session_state.pop("flash"))

students = db.get_students()
if students.empty:
    st.info("No students found. Add students first.")
    st.stop()

names = {r["student_id"]: f"{r['student_id']} - {r['name']}" for _, r in students.iterrows()}

tab_mark, tab_hist, tab_low = st.tabs(["✅ Mark Attendance", "📜 History & Percentage", "⚠️ Low Attendance (<75%)"])

# ---------------- Mark ----------------
with tab_mark:
    with st.form("attendance_form"):
        sid = st.selectbox("Select student", list(names), format_func=lambda x: names[x])
        att_date = st.date_input("Select date", value=date.today())
        status = st.radio("Status", ["Present", "Absent"], horizontal=True)
        save = st.form_submit_button("Save Attendance")
    if save:
        ok, msg = db.add_attendance(sid, att_date.isoformat(), status)
        (st.success if ok else st.warning)(msg)

# ---------------- History ----------------
with tab_hist:
    options = [None] + list(names)
    pick = st.selectbox("Filter by student", options, format_func=lambda x: "All students" if x is None else names[x],
                        key="hist_student")
    history = db.get_attendance_history(student_id=pick)
    if history.empty:
        st.info("No attendance records found.")
    else:
        st.dataframe(history, use_container_width=True, hide_index=True)

        st.subheader("Attendance percentage (Present classes / Total classes × 100)")
        summary = db.get_student_summary()
        if pick:
            summary = summary[summary["student_id"] == pick]
        shown = summary[summary["total_classes"] > 0][
            ["student_id", "name", "total_classes", "present_days", "absent_days", "attendance_pct"]]
        st.dataframe(shown, use_container_width=True, hide_index=True)

        st.subheader("Correct or delete a record")
        labels = {int(r["id"]): f"#{int(r['id'])} | {r['student_id']} | {r['date']} | {r['status']}"
                  for _, r in history.iterrows()}
        rec = st.selectbox("Select record", list(labels), format_func=lambda x: labels[x], key="rec_pick")
        new_status = st.radio("New status", ["Present", "Absent"], horizontal=True, key="rec_status")
        c1, c2 = st.columns(2)
        if c1.button("Update Status"):
            ok, msg = db.update_attendance_status(rec, new_status)
            if ok:
                st.session_state["flash"] = msg
                st.rerun()
            else:
                st.error(msg)
        if c2.button("Delete Record"):
            ok, msg = db.delete_attendance(rec)
            if ok:
                st.session_state["flash"] = msg
                st.rerun()
            else:
                st.error(msg)

# ---------------- Low attendance ----------------
with tab_low:
    low = an.low_attendance_students(db.get_student_summary())
    if low.empty:
        st.success("No students are below 75% attendance (or no attendance has been recorded yet).")
    else:
        st.warning(f"{len(low)} student(s) have attendance below 75%.")
        st.dataframe(low, use_container_width=True, hide_index=True)
