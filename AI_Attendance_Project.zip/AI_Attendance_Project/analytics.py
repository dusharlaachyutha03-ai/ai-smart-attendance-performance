"""
analytics.py  -  Helper functions that build Plotly charts and tables.
The pages only call these functions, so chart code stays in one place.
"""
import numpy as np
import pandas as pd
import plotly.express as px

TEMPLATE = "plotly_white"
ATT_LIMIT = 75


def _label(df):
    df = df.copy()
    df["label"] = df["name"] + " (" + df["student_id"].astype(str) + ")"
    return df


def attendance_overview_fig(history):
    if history.empty:
        return None
    counts = history["status"].value_counts().reset_index()
    counts.columns = ["status", "count"]
    return px.pie(counts, names="status", values="count", hole=0.45, template=TEMPLATE,
                  color="status", color_discrete_map={"Present": "#2E9E5B", "Absent": "#D64545"},
                  title="Attendance Overview (all records)")


def student_performance_fig(summary):
    df = summary.dropna(subset=["avg_marks"])
    if df.empty:
        return None
    df = _label(df).sort_values("avg_marks", ascending=False)
    fig = px.bar(df, x="label", y="avg_marks", color="avg_marks", template=TEMPLATE,
                 color_continuous_scale="Blues", title="Student Performance (Average Marks)",
                 labels={"label": "Student", "avg_marks": "Average Marks"})
    fig.update_layout(yaxis_range=[0, 100], xaxis_tickangle=-40)
    return fig


def attendance_vs_marks_fig(summary):
    df = summary.dropna(subset=["attendance_pct", "avg_marks"])
    if df.empty:
        return None
    df = _label(df)
    fig = px.scatter(df, x="attendance_pct", y="avg_marks", color="department",
                     hover_name="label", template=TEMPLATE, title="Attendance vs Marks",
                     labels={"attendance_pct": "Attendance %", "avg_marks": "Average Marks"})
    fig.update_traces(marker=dict(size=11))
    fig.add_vline(x=ATT_LIMIT, line_dash="dash", line_color="red")
    return fig


def department_students_fig(summary):
    if summary.empty:
        return None
    counts = summary["department"].value_counts().reset_index()
    counts.columns = ["department", "students"]
    return px.bar(counts, x="department", y="students", color="department", template=TEMPLATE,
                  title="Department-wise Students")


def risk_fig(risk_df):
    if risk_df.empty:
        return None
    counts = risk_df["risk"].value_counts().reset_index()
    counts.columns = ["risk", "students"]
    return px.pie(counts, names="risk", values="students", hole=0.45, template=TEMPLATE,
                  color="risk", title="Good vs At-Risk Students",
                  color_discrete_map={"Good": "#2E9E5B", "At Risk": "#D64545", "No Data": "#9AA0A6"})


def student_attendance_fig(summary):
    df = summary.dropna(subset=["attendance_pct"])
    if df.empty:
        return None
    df = _label(df).sort_values("attendance_pct")
    fig = px.bar(df, x="label", y="attendance_pct", template=TEMPLATE,
                 title="Student-wise Attendance %", labels={"label": "Student", "attendance_pct": "Attendance %"})
    fig.add_hline(y=ATT_LIMIT, line_dash="dash", line_color="red", annotation_text="75% limit")
    fig.update_layout(yaxis_range=[0, 100], xaxis_tickangle=-40)
    return fig


def subject_marks_fig(marks):
    if marks.empty:
        return None
    avg = marks.groupby("subject", as_index=False)["marks"].mean().sort_values("marks", ascending=False)
    avg["marks"] = avg["marks"].round(2)
    return px.bar(avg, x="subject", y="marks", color="subject", template=TEMPLATE, text="marks",
                  title="Subject-wise Average Marks", labels={"marks": "Average Marks"})


def department_performance_fig(summary):
    df = summary.dropna(subset=["avg_marks"])
    if df.empty:
        return None
    grp = df.groupby("department", as_index=False).agg(
        avg_marks=("avg_marks", "mean"), avg_attendance=("attendance_pct", "mean")).round(2)
    long = grp.melt(id_vars="department", var_name="measure", value_name="value")
    long["measure"] = long["measure"].map({"avg_marks": "Average Marks", "avg_attendance": "Average Attendance %"})
    return px.bar(long, x="department", y="value", color="measure", barmode="group",
                  template=TEMPLATE, title="Department-wise Performance")


def correlation(summary):
    """Correlation between attendance % and average marks (None if not possible)."""
    df = summary.dropna(subset=["attendance_pct", "avg_marks"])
    if len(df) < 3 or df["attendance_pct"].nunique() < 2 or df["avg_marks"].nunique() < 2:
        return None
    return float(np.corrcoef(df["attendance_pct"], df["avg_marks"])[0, 1])


def top_students(summary, n=5):
    df = summary.dropna(subset=["avg_marks"]).sort_values("avg_marks", ascending=False).head(n)
    return df[["student_id", "name", "department", "avg_marks", "attendance_pct"]]


def low_students(summary, n=5):
    df = summary.dropna(subset=["avg_marks"]).sort_values("avg_marks").head(n)
    return df[["student_id", "name", "department", "avg_marks", "attendance_pct"]]


def low_attendance_students(summary):
    df = summary[(summary["total_classes"] > 0) & (summary["attendance_pct"] < ATT_LIMIT)]
    return df[["student_id", "name", "department", "total_classes", "present_days",
               "absent_days", "attendance_pct"]].sort_values("attendance_pct")
