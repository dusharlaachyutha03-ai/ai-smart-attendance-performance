"""
database.py  -  All SQLite database code lives here.
Every query is parameterized (uses ?) so it is safe from SQL injection.
"""
import os
import re
import sqlite3
from contextlib import closing

import pandas as pd

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
DB_PATH = os.path.join(DATA_DIR, "attendance.db")

DEPARTMENTS = ["CSE", "IT", "ECE", "EEE", "Mechanical", "Civil", "AI & DS", "Other"]
EXAM_TYPES = ["Unit Test", "Mid Term", "Final Exam", "Assignment", "Lab"]
ATTENDANCE_LIMIT = 75  # percent


# ----------------------------------------------------------------------
# Connection + table creation
# ----------------------------------------------------------------------
def get_connection():
    os.makedirs(DATA_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")  # needed for foreign keys in SQLite
    return conn


def init_db():
    """Create the three tables if they do not exist yet."""
    try:
        with closing(get_connection()) as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS students (
                    student_id  TEXT PRIMARY KEY,
                    roll_number TEXT NOT NULL UNIQUE,
                    name        TEXT NOT NULL,
                    department  TEXT NOT NULL,
                    year        INTEGER NOT NULL CHECK (year BETWEEN 1 AND 6),
                    email       TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS attendance (
                    id         INTEGER PRIMARY KEY AUTOINCREMENT,
                    student_id TEXT NOT NULL,
                    date       TEXT NOT NULL,
                    status     TEXT NOT NULL CHECK (status IN ('Present', 'Absent')),
                    UNIQUE (student_id, date),
                    FOREIGN KEY (student_id) REFERENCES students (student_id)
                        ON DELETE CASCADE ON UPDATE CASCADE
                );

                CREATE TABLE IF NOT EXISTS performance (
                    id         INTEGER PRIMARY KEY AUTOINCREMENT,
                    student_id TEXT NOT NULL,
                    subject    TEXT NOT NULL,
                    marks      REAL NOT NULL CHECK (marks BETWEEN 0 AND 100),
                    exam_type  TEXT NOT NULL,
                    UNIQUE (student_id, subject, exam_type),
                    FOREIGN KEY (student_id) REFERENCES students (student_id)
                        ON DELETE CASCADE ON UPDATE CASCADE
                );
                """
            )
            conn.commit()
        return True
    except sqlite3.Error as e:
        print("init_db error:", e)
        return False


# ----------------------------------------------------------------------
# Small helpers
# ----------------------------------------------------------------------
def _read(sql, params=()):
    """Run a SELECT and return a DataFrame (empty DataFrame on error)."""
    try:
        with closing(get_connection()) as conn:
            return pd.read_sql_query(sql, conn, params=params)
    except Exception as e:  # noqa
        print("read error:", e)
        return pd.DataFrame()


def _execute(sql, params=(), ok_msg="Saved successfully.",
             dup_msg="This record already exists."):
    """Run INSERT / UPDATE / DELETE. Returns (True/False, message)."""
    try:
        with closing(get_connection()) as conn:
            with conn:  # commits automatically, rolls back on error
                cur = conn.execute(sql, params)
                if cur.rowcount == 0:
                    return False, "No matching record found."
        return True, ok_msg
    except sqlite3.IntegrityError as e:
        text = str(e)
        if "UNIQUE" in text:
            return False, dup_msg
        if "FOREIGN KEY" in text:
            return False, "The selected student does not exist."
        return False, "The database did not accept this data. Please check your input."
    except sqlite3.Error as e:
        print("execute error:", e)
        return False, "Database error. Please try again."


def _clean(value):
    """Turn NaN/None into '' and strip spaces from everything else."""
    if value is None or (not isinstance(value, str) and pd.isna(value)):
        return ""
    return str(value).strip()


def _validate_student(student_id, roll, name, dept, year, email):
    """Return an error message, or None when everything is fine."""
    if not student_id or not roll or not name or not dept or not email:
        return "All fields are required."
    try:
        y = int(year)
    except (TypeError, ValueError):
        return "Year must be a number."
    if y < 1 or y > 6:
        return "Year must be between 1 and 6."
    if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", email):
        return "Please enter a valid email address."
    return None


def _validate_marks(subject, marks):
    if not subject:
        return "Subject is required."
    try:
        m = float(marks)
    except (TypeError, ValueError):
        return "Marks must be a number."
    if m < 0 or m > 100:
        return "Marks must be between 0 and 100."
    return None


# ----------------------------------------------------------------------
# Students
# ----------------------------------------------------------------------
def add_student(student_id, roll, name, dept, year, email):
    student_id, roll, name = _clean(student_id), _clean(roll), _clean(name)
    dept, email = _clean(dept), _clean(email)
    err = _validate_student(student_id, roll, name, dept, year, email)
    if err:
        return False, err
    return _execute(
        "INSERT INTO students (student_id, roll_number, name, department, year, email) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (student_id, roll, name, dept, int(year), email),
        ok_msg="Student added successfully.",
        dup_msg="Student ID or Roll Number already exists.",
    )


def get_students():
    return _read("SELECT * FROM students ORDER BY student_id")


def search_students(term):
    like = f"%{_clean(term)}%"
    return _read(
        "SELECT * FROM students WHERE student_id LIKE ? OR roll_number LIKE ? "
        "OR name LIKE ? OR department LIKE ? OR email LIKE ? ORDER BY student_id",
        (like, like, like, like, like),
    )


def update_student(student_id, roll, name, dept, year, email):
    roll, name, dept, email = _clean(roll), _clean(name), _clean(dept), _clean(email)
    err = _validate_student(student_id, roll, name, dept, year, email)
    if err:
        return False, err
    return _execute(
        "UPDATE students SET roll_number=?, name=?, department=?, year=?, email=? "
        "WHERE student_id=?",
        (roll, name, dept, int(year), email, student_id),
        ok_msg="Student updated successfully.",
        dup_msg="Another student already uses this Roll Number.",
    )


def delete_student(student_id):
    """Also deletes the student's attendance and marks (ON DELETE CASCADE)."""
    return _execute("DELETE FROM students WHERE student_id=?", (student_id,),
                    ok_msg="Student and related records deleted.")


# ----------------------------------------------------------------------
# Attendance
# ----------------------------------------------------------------------
def add_attendance(student_id, date_str, status):
    if status not in ("Present", "Absent"):
        return False, "Status must be Present or Absent."
    return _execute(
        "INSERT INTO attendance (student_id, date, status) VALUES (?, ?, ?)",
        (student_id, str(date_str), status),
        ok_msg="Attendance saved successfully.",
        dup_msg="Attendance for this student on this date is already saved.",
    )


def get_attendance_history(student_id=None, start=None, end=None):
    sql = (
        "SELECT a.id, a.student_id, s.name, s.department, a.date, a.status "
        "FROM attendance a JOIN students s ON s.student_id = a.student_id WHERE 1=1"
    )
    params = []
    if student_id:
        sql += " AND a.student_id = ?"
        params.append(student_id)
    if start:
        sql += " AND a.date >= ?"
        params.append(str(start))
    if end:
        sql += " AND a.date <= ?"
        params.append(str(end))
    sql += " ORDER BY a.date DESC, a.student_id"
    return _read(sql, tuple(params))


def update_attendance_status(record_id, status):
    if status not in ("Present", "Absent"):
        return False, "Status must be Present or Absent."
    return _execute("UPDATE attendance SET status=? WHERE id=?", (status, int(record_id)),
                    ok_msg="Attendance record updated.")


def delete_attendance(record_id):
    return _execute("DELETE FROM attendance WHERE id=?", (int(record_id),),
                    ok_msg="Attendance record deleted.")


def get_today_counts(date_str):
    df = _read("SELECT status, COUNT(*) AS n FROM attendance WHERE date=? GROUP BY status",
               (str(date_str),))
    present = absent = 0
    for _, r in df.iterrows():
        if r["status"] == "Present":
            present = int(r["n"])
        elif r["status"] == "Absent":
            absent = int(r["n"])
    return present, absent


# ----------------------------------------------------------------------
# Performance (marks)
# ----------------------------------------------------------------------
def add_marks(student_id, subject, marks, exam_type):
    subject, exam_type = _clean(subject), _clean(exam_type)
    err = _validate_marks(subject, marks)
    if err:
        return False, err
    if not exam_type:
        return False, "Exam type is required."
    return _execute(
        "INSERT INTO performance (student_id, subject, marks, exam_type) VALUES (?, ?, ?, ?)",
        (student_id, subject, float(marks), exam_type),
        ok_msg="Marks added successfully.",
        dup_msg="Marks for this student, subject and exam type already exist. Use Update instead.",
    )


def get_marks(student_id=None):
    sql = (
        "SELECT p.id, p.student_id, s.name, s.department, p.subject, p.marks, p.exam_type "
        "FROM performance p JOIN students s ON s.student_id = p.student_id"
    )
    params = ()
    if student_id:
        sql += " WHERE p.student_id = ?"
        params = (student_id,)
    sql += " ORDER BY p.student_id, p.subject"
    return _read(sql, params)


def update_marks(record_id, subject, marks, exam_type):
    subject, exam_type = _clean(subject), _clean(exam_type)
    err = _validate_marks(subject, marks)
    if err:
        return False, err
    return _execute(
        "UPDATE performance SET subject=?, marks=?, exam_type=? WHERE id=?",
        (subject, float(marks), exam_type, int(record_id)),
        ok_msg="Marks updated successfully.",
        dup_msg="Another record with the same student, subject and exam type already exists.",
    )


def delete_marks(record_id):
    return _execute("DELETE FROM performance WHERE id=?", (int(record_id),),
                    ok_msg="Marks record deleted.")


# ----------------------------------------------------------------------
# Combined summary (used by dashboard, analytics and machine learning)
# ----------------------------------------------------------------------
def get_student_summary():
    """One row per student with attendance % and average marks."""
    return _read(
        """
        SELECT s.student_id, s.roll_number, s.name, s.department, s.year,
               COALESCE(a.total, 0)   AS total_classes,
               COALESCE(a.present, 0) AS present_days,
               COALESCE(a.absent, 0)  AS absent_days,
               CASE WHEN COALESCE(a.total, 0) > 0
                    THEN ROUND(a.present * 100.0 / a.total, 2) END AS attendance_pct,
               p.avg_marks,
               COALESCE(p.subjects, 0) AS num_subjects
        FROM students s
        LEFT JOIN (SELECT student_id, COUNT(*) AS total,
                          SUM(CASE WHEN status='Present' THEN 1 ELSE 0 END) AS present,
                          SUM(CASE WHEN status='Absent'  THEN 1 ELSE 0 END) AS absent
                   FROM attendance GROUP BY student_id) a ON a.student_id = s.student_id
        LEFT JOIN (SELECT student_id, ROUND(AVG(marks), 2) AS avg_marks,
                          COUNT(DISTINCT subject) AS subjects
                   FROM performance GROUP BY student_id) p ON p.student_id = s.student_id
        ORDER BY s.student_id
        """
    )


# ----------------------------------------------------------------------
# Bulk import (used by the Upload page)
# ----------------------------------------------------------------------
def _bulk_insert(df, sql, row_to_params):
    inserted, skipped, errors = 0, 0, []
    df = df.reset_index(drop=True)
    try:
        with closing(get_connection()) as conn:
            for i, row in df.iterrows():
                line = i + 2  # +1 for header row, +1 because Excel rows start at 1
                try:
                    params = row_to_params(conn, row)
                except ValueError as e:
                    errors.append(f"Row {line}: {e}")
                    continue
                cur = conn.execute(sql, params)
                if cur.rowcount > 0:
                    inserted += 1
                else:
                    skipped += 1  # duplicate, ignored
            conn.commit()
    except sqlite3.Error as e:
        print("bulk insert error:", e)
        errors.append("Database error while importing. Nothing after this point was saved.")
    return inserted, skipped, errors


def _student_exists(conn, student_id):
    return conn.execute("SELECT 1 FROM students WHERE student_id=?", (student_id,)).fetchone() is not None


def import_students(df):
    def convert(conn, row):
        vals = [_clean(row.get(c)) for c in
                ("student_id", "roll_number", "name", "department", "year", "email")]
        try:
            vals[4] = str(int(float(vals[4])))
        except ValueError:
            raise ValueError("Year must be a number.")
        err = _validate_student(*vals)
        if err:
            raise ValueError(err)
        return (vals[0], vals[1], vals[2], vals[3], int(vals[4]), vals[5])

    return _bulk_insert(
        df,
        "INSERT OR IGNORE INTO students (student_id, roll_number, name, department, year, email) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        convert,
    )


def import_attendance(df):
    def convert(conn, row):
        sid = _clean(row.get("student_id"))
        if not _student_exists(conn, sid):
            raise ValueError(f"Student ID '{sid}' not found. Upload students first.")
        date = pd.to_datetime(_clean(row.get("date")), errors="coerce")
        if pd.isna(date):
            raise ValueError("Invalid date (use YYYY-MM-DD).")
        raw = _clean(row.get("status")).lower()
        if raw in ("present", "p"):
            status = "Present"
        elif raw in ("absent", "a"):
            status = "Absent"
        else:
            raise ValueError("Status must be Present or Absent.")
        return (sid, date.strftime("%Y-%m-%d"), status)

    return _bulk_insert(
        df, "INSERT OR IGNORE INTO attendance (student_id, date, status) VALUES (?, ?, ?)", convert
    )


def import_performance(df):
    def convert(conn, row):
        sid = _clean(row.get("student_id"))
        if not _student_exists(conn, sid):
            raise ValueError(f"Student ID '{sid}' not found. Upload students first.")
        subject, exam = _clean(row.get("subject")), _clean(row.get("exam_type"))
        marks = _clean(row.get("marks"))
        err = _validate_marks(subject, marks)
        if err:
            raise ValueError(err)
        if not exam:
            raise ValueError("Exam type is required.")
        return (sid, subject, float(marks), exam)

    return _bulk_insert(
        df,
        "INSERT OR IGNORE INTO performance (student_id, subject, marks, exam_type) VALUES (?, ?, ?, ?)",
        convert,
    )
